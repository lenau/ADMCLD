const express = require('express')
const app = express()
const port = process.env.PORT || 8080;
app.set('port', port);

app.get('/admcld', (req, res) => {
  res.status(200).send('This is ADMCLD!')
  console.log('ADMCLD executed')
})

app.get('/starwars', (req, res) => {
  res.status(200).send('<!DOCTYPE html><html>    <head>        <style>            body {  width: 100%;  height: 100%;  background: #000;  overflow: hidden;}.fade {  position: relative;  width: 100%;  min-height: 60vh;  top: -25px;  background-image: linear-gradient(0deg, transparent, black 75%);  z-index: 1;}.star-wars {  display: flex;  justify-content: center;  position: relative;  height: 800px;  color: #feda4a;  font-family: "Pathway Gothic One", sans-serif;  font-size: 500%;  font-weight: 600;  letter-spacing: 6px;  line-height: 150%;  perspective: 400px;  text-align: justify;}.crawl {  position: relative;  top: 9999px;  transform-origin: 50% 100%;  animation: crawl 60s linear;}.crawl > .title {  font-size: 90%;  text-align: center;}.crawl > .title h1 {  margin: 0 0 100px;  text-transform: uppercase;}@keyframes crawl {  0% {    top: 0;    transform: rotateX(20deg)  translateZ(0);  }  100% {     top: -6000px;    transform: rotateX(25deg) translateZ(-2500px);  }}        </style>    </head>    <body>        <div class="fade"></div><section class="star-wars">  <div class="crawl">    <div class="title">      <p>Episode IV</p>      <h1>A New Hope</h1>    </div>        <p>It is a period of civil war. Rebel spaceships, striking from a hidden base, have won their first victory against the evil Galactic Empire.</p>          <p>During the battle, Rebel spies managed to steal secret plans to the Empire’s ultimate weapon, the DEATH STAR, an armored space station with enough power to destroy an entire planet.</p>    <p>Pursued by the Empire’s sinister agents, Princess Leia races home aboard her starship, custodian of the stolen plans that can save her people and restore freedom to the galaxy…</p>  </div></section>    </body></html>')
  console.log('Star Wars executed')
})

app.get('/snake', (req, res) => {
  res.status(200).send("<!DOCTYPE html><html><head>  <title>Basic Snake HTML Game</title>  <meta charset='UTF-8'>  <style>  html, body {    height: 100%;    margin: 0;  }  body {    background: black;    display: flex;    align-items: center;    justify-content: center;  }  canvas {    border: 1px solid white;  }  </style></head><body><canvas width='400' height='400' id='game'></canvas><script>var canvas = document.getElementById('game');var context = canvas.getContext('2d');var grid = 16;var count = 0;var snake = {  x: 160,  y: 160,  dx: grid,  dy: 0,  cells: [],   maxCells: 4};var apple = {  x: 320,  y: 320};function getRandomInt(min, max) {  return Math.floor(Math.random() * (max - min)) + min;}function loop() {  requestAnimationFrame(loop);  if (++count < 4) {    return;  }  count = 0;  context.clearRect(0,0,canvas.width,canvas.height);  snake.x += snake.dx;  snake.y += snake.dy;  if (snake.x < 0) {    snake.x = canvas.width - grid;  }  else if (snake.x >= canvas.width) {    snake.x = 0;  }  if (snake.y < 0) {    snake.y = canvas.height - grid;  }  else if (snake.y >= canvas.height) {    snake.y = 0;  }  snake.cells.unshift({x: snake.x, y: snake.y});  if (snake.cells.length > snake.maxCells) {    snake.cells.pop();  }  context.fillStyle = 'red';  context.fillRect(apple.x, apple.y, grid-1, grid-1);  context.fillStyle = 'green';  snake.cells.forEach(function(cell, index) {    context.fillRect(cell.x, cell.y, grid-1, grid-1);    if (cell.x === apple.x && cell.y === apple.y) {      snake.maxCells++;      apple.x = getRandomInt(0, 25) * grid;      apple.y = getRandomInt(0, 25) * grid;    }    for (var i = index + 1; i < snake.cells.length; i++) {      if (cell.x === snake.cells[i].x && cell.y === snake.cells[i].y) {        snake.x = 160;        snake.y = 160;        snake.cells = [];        snake.maxCells = 4;        snake.dx = grid;        snake.dy = 0;        apple.x = getRandomInt(0, 25) * grid;        apple.y = getRandomInt(0, 25) * grid;      }    }  });}document.addEventListener('keydown', function(e) {  if (e.which === 37 && snake.dx === 0) {    snake.dx = -grid;    snake.dy = 0;  }  else if (e.which === 38 && snake.dy === 0) {    snake.dy = -grid;    snake.dx = 0;  }  else if (e.which === 39 && snake.dx === 0) {    snake.dx = grid;    snake.dy = 0;  }  else if (e.which === 40 && snake.dy === 0) {    snake.dy = grid;    snake.dx = 0;  }});requestAnimationFrame(loop);</script></body></html>")
  console.log('Snake executed')
})

app.get('/hello', (req, res) => {
  res.status(200).send('Hello World!')
  console.log('Hello World executed')
})


app.get('*', (req, res) => {
  res.status(200).send('Hello world landing page')
  console.log('Landing page executed')
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
